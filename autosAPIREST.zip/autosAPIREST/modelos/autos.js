var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var AutoSchema = {
  color:String,
  caballos:Number,
  modelo:Number,
  segmento:String,
  marca:String,
  submarca:String
};

module.export = mongoose.model('Autos',AutoSchema);
